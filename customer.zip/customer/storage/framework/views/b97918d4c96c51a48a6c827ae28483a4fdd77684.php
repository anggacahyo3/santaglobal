<!DOCTYPE html>
<html>
<head>
	<title>Laravel 5.5 CRUD Application</title>
	<link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('css/styles.css')); ?>" rel="stylesheet">

	<!-- jquery -->
	<script type="text/javascript" src="<?php echo e(asset('js/jquery/jquery-3.3.1.min.js')); ?>"></script>

	<!-- datatables -->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('DataTables/datatables.min.css')); ?>">
	<script type="text/javascript" charset="utf8" src="<?php echo e(asset('DataTables/datatables.min.js')); ?>"></script>
</head>
<body>
	 <?php echo $__env->yieldContent('content'); ?>
</div>

</body>
</html>
