<?php $__env->startSection('content'); ?>

	<h2>Bienvenido</h2>
	<!-- customers es el alias del controller. customersList es el metodo en el controller -->
	<!--<a class="btn btn-primary" href="<?php echo e(route('customers.index')); ?>">Go to customers list</a>-->
	<a class="btn btn-primary" href="<?php echo e(route('customers.index')); ?>">Ingrese aqui</a>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>