<?php $__env->startSection('content'); ?>

<h2 class="customerBanner btn-warning">Customers list</h2>

<div class="container">
	<div class="row">
	</br>
</br>

<table id="customersTable" class="table table-bordered">
	<thead>
		<tr>
			<th>Id</th>
			<th>Nama</th>
			<th>Tipe</th>
		</tr>
	</thead>

	<tbody>
		<!--variables que viene del controller customers-->
		<?php $__currentLoopData = $customersList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($customer->id); ?></td>
			<td><?php echo e($customer->nama); ?></td>
			<td><?php echo e($customer->tipe); ?></td>

		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>

<br/>
<a class="btn btn-success" href="<?php echo e(route('customers.create')); ?>">Create a customer</a>

</div>
</div>

<script type="text/javascript">
	$(document).ready(function() {
		$('#customersTable').DataTable();
	});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>