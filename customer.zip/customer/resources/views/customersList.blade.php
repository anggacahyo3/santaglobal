@extends('layout')

@section('content')

<h2 class="customerBanner btn-warning">Customers list</h2>

<div class="container">
	<div class="row">
	</br>
</br>

<table id="customersTable" class="table table-bordered">
	<thead>
		<tr>
			<th>Id</th>
			<th>Nama</th>
			<th>Tipe</th>
		</tr>
	</thead>

	<tbody>
		<!--variables que viene del controller customers-->
		@foreach ($customersList as $customer)
		<tr>
			<td>{{ $customer->id}}</td>
			<td>{{ $customer->nama}}</td>
			<td>{{ $customer->tipe}}</td>

		</tr>
		@endforeach
	</tbody>
</table>

<br/>
<a class="btn btn-success" href="{{ route('customers.create') }}">Create a customer</a>

</div>
</div>

<script type="text/javascript">
	$(document).ready(function() {
		$('#customersTable').DataTable();
	});
</script>

@endsection
