<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Relasi extends Model {

	public $timestamps = false;

	protected $primaryKey = 'id';

	/**
	 * The attributes that are mass assignable.
	 *
	 * @var array
	 */
	protected $fillable = [
		'nama', 'tipe',
	];
}