<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Relasi;

class RepoController extends Controller
{
    public function GetListRelasi() {

		$customersList = Relasi::all();
		//return json_encode($customersList);
		return $customersList;
	}
}
