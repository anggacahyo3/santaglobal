<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class RelasiController extends Controller
{
        public function index() {

		$customersList=app('App\Http\Controllers\RepoController')->GetListRelasi();
		return view('customersList', compact('customersList'));
	}
}
